/**
 * Created by Qiang on 2019/5/30.
 */
$(document).ready(function(){
    $('#dwBodyLeftContent').on('click','a',function(e){
        var target = e.target;
        var id = $(target).data("ext");
        if(id){
            var $node= $("input[value='"+id+"']");
            console.log($node);
            if($node.length>0) {
                var $nodeParent = $node.parents('.li_surveyQuItemBody');
                if($nodeParent){
                    var prevPageNo=  $nodeParent[0].classList[1].replace('surveyQu_','');
                    $(".li_surveyQuItemBody").hide();
                    $(".surveyQu_"+prevPageNo).fadeIn("slow");
                    $('html,body').animate({scrollTop:$nodeParent.offset().top}, 800);
                }
            }
        }
    });
    //选项单击
    $(".dwQuOptionItemContent").click(function(){
        var thObj=$(this);
        var quItemBody=thObj.parents(".li_surveyQuItemBody");
        var quType=quItemBody.find(".quType").val();
        var dwQuInputLabel=thObj.find(".dwQuInputLabel");
        if("1"===quType||"7"===quType){
            //单选题
            quItemBody.find(".dwQuInputLabel").removeClass("checked");
            quItemBody.find("input[type='radio']").prop("checked",false);
            dwQuInputLabel.addClass("checked");
            thObj.find("input[type='radio']").prop("checked",true);
            //  quItemBody.find(".saveTag").val(1);
        }else if("2"===quType||"13"===quType||"14"===quType){
            //多选题
            var quInputLabelClass=dwQuInputLabel.attr("class");
            if(quInputLabelClass.indexOf("checked")>0){
                dwQuInputLabel.removeClass("checked");
                thObj.find("input[type='checkbox']").prop("checked",false);

            }else{
                dwQuInputLabel.addClass("checked");
                thObj.find("input[type='checkbox']").prop("checked",true);
                if(thObj.hasClass('quIsUninvo')){
                    //排除过控被选择
                    quItemBody.find(".quCoItemUlLi .dwQuOptionItemContent .dwQuInputLabel").removeClass('checked');
                    quItemBody.find(".quCoItemUlLi .dwQuOptionItemContent input[type='checkbox']").prop("checked",false)
                }
            }
        }
        if("2"===quType||"1"===quType) {
            //单选或多选子级处理
            var quItemRadio = $(this).find("input[type='radio']");
            var quItemCheck = $(this).find("input[type='checkbox']");
            if (quItemCheck.length > 0 || quItemRadio.length > 0) {
                var quItemTrigger = $(this).find("input[name='trigger']");
                if (quItemTrigger.val() == '1') {
                    var quQuId = $(this).parents('.surveyQuItem').prev().find("input[name='quId']");
                    if (quQuId.length > 0 && quQuId.val()) {
                        layer.open({
                            type: 2,
                            title: false,
                            shadeClose: true,
                            shade: 0.8,
                            area: ['80%', '96%'],
                            content: '/Survey/previewChild/763bd254694e92bcc64ac8d71ea51479?quId=' + quQuId.val(),
                        });

                    }
                }
            }
        }
    });
    //分页设置 nextPage_a prevPage_a
    $(".nextPage_a").click(function(){
        var thParent=$(this).parent();
        var nextPageNo=thParent.find("input[name='nextPageNo']").val();
        $(".li_surveyQuItemBody").hide();
        $(".surveyQu_"+nextPageNo).fadeIn("slow");
        $("html,body").animate({scrollTop:10},500);
        return false;
    });
    $(".prevPage_a").click(function(){
        var thParent=$(this).parent();
        var prevPageNo=thParent.find("input[name='prevPageNo']").val();
        $(".li_surveyQuItemBody").hide();
        $(".surveyQu_"+prevPageNo).fadeIn("slow");
        $(window).scrollTop(10);
        return false;
    });
    $("input[name='showTiNum']").change(function(){
        if($(this).prop("checked")){
            $(".quCoNum").show();
        }else{
            $(".quCoNum").hide();
        }
        return false;
    });
//            $("input[name='showProgressbar']").change(function(){
//                if($(this).prop("checked")){
//                    $("#resultProgressRoot").show();
//                }else{
//                    $("#resultProgressRoot").hide();
//                }
//                return false;
//            });
    //问卷标题
    $("input[name='showSurTitle']").change(function(){
        if($(this).prop("checked")){
            $("#dwSurveyTitle").show();
        }else{
            $("#dwSurveyTitle").hide();
        }
        return false;
    });
    $("input[name='showSurNote']").change(function(){
        if($(this).prop("checked")){
            $("#dwSurveyNote").show();
        }else{
            $("#dwSurveyNote").hide();
        }
        return false;
    });
    $("input[name='showSurHead']").change(function(){
        if($(this).prop("checked")){
            $("#dwSurveyHeader").show();
        }else{
            $("#dwSurveyHeader").hide();
        }
        return false;
    });

    //返回列表
    $("#btnGoToList").click(function(){
        // window.location.href="/Survey";
        window.opener=null;
        window.open('','_self');
        window.close();
    });
});